#!/bin/bash
source /opt/tp/scripts/esLaborable.sh

#(migrate for backend in node operations)
#eliminar feriado


#agregar feriado


#actualizar feriado

esLaborable $1