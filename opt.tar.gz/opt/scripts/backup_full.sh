#!/bin/bash

#Ayuda
if [[ "$1" == "--help" ]]; then
	echo "Uso: $0 [directorio_origen] [directorio_destino]"
	echo "Opciones:"
	echo " --help	Muestra esta ayuda"
	echo " Si no se pasa ningun argumento backupean de /var/log y /www_dir."
	exit 0
fi


#a quier hago BK
if [ -n "$1" ]; then
	DIRECTORIOS=("$1")
else

	DIRECTORIOS=("/var/log" "/www_dir")
fi

# Destino por argumento
DESTINO="$2"

if [ -z "$DESTINO" ]; then
	echo "Error: Debe ingresar el destino como segundo parametro"
	echo "Ejemplo: $0 /var/log /backup_dir"
	exit 1
fi

# validar existencia

if [ ! -d "$DESTINO" ]; then
	echo "Error: El directorio destino $DESTINO no existe."
	exit 1
fi

#Fecha ANSI
FECHA=$(date +%Y%m%d)

# Backupear
for DIR in "#{DIRECTORIOS[@]}"
do
	if [ -d "$DIR" ]; then
		NOMBRE=$(basename "$DIR" | tr -d '/')
		tar -czf "${DESTINO}/${NOMBRE}_BKP_${FECHA}.tar.gz" "$DIR"
	else
		echo "Advertencia: Ek directorio $DIR no existe. Se Omite"
	fi
done
echo "BK completo en $DESTINO"

