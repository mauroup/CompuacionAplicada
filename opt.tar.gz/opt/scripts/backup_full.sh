#!/bin/bash

#Ayuda
if [[ "$1" == "-help" ]]; then
	echo "Uso: $0 [directorio]"
	echo "Opciones:"
	echo " -help	Muestra esta ayuda"
	echo " Sin Opciones: hace backup de /var/log y /www_dir."
	echo " Si se pasa un directorio como argumento, solo backapea ese directorio."
	exit 0
fi


#a quier hago BK
DIRECTORIOS=("/var/log" "/www_dir")

#a donde lo mando
DESTINO="/backup_dir"

#obtenemos decha actual
FECHA=$(date +%Y%m%m)

#verifico si existe destino (me esta fallando el bk)
if [ ! -d "$DESTINO" ]; then
	echo "Error: El directorio destino $DESTINO no existe."
	exit 1
fi

if [ -n "$1"]; then
	#si recibo argumento
	DIRECTORIOS=("$1")
else
	#si No recibo argumentos	
	DIRECTORIOS=("/var/log" "/www.dir") 	
fi


#hacemos bk

for DIR in "${DIRECTORIOS[@]}"
do
    if [ -d "$DIR" ]; then	
	#extraer el nombre del directorio
	NOMBRE=$(basename "$DIR")
	#crea bk
	tar -czf "${DESTINO}/${NOMBRE}_BKP_${FECHA}.tar.gz" "$DIR"
    else
	echo "Advertencia: El directorio $DIR no existe.Se omite"
    fi

done

echo "BK completo en $DESTINO"
